-- Azure SQL seed destination: patient_master
IF OBJECT_ID('dbo.patient_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.patient_master (
    [patient_id] NVARCHAR(255) NULL,
    [synthetic_patient_code] NVARCHAR(255) NULL,
    [age_band] NVARCHAR(255) NULL,
    [sex] NVARCHAR(255) NULL,
    [city] NVARCHAR(255) NULL,
    [registration_date] NVARCHAR(255) NULL,
    [consent_flag] NVARCHAR(255) NULL,
    [insurance_type] NVARCHAR(255) NULL,
    [patient_status] NVARCHAR(255) NULL,
    [primary_language] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: department_master
IF OBJECT_ID('dbo.department_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.department_master (
    [department_id] NVARCHAR(255) NULL,
    [department_name] NVARCHAR(255) NULL,
    [specialty] NVARCHAR(255) NULL,
    [hospital_site] NVARCHAR(255) NULL,
    [floor] NVARCHAR(255) NULL,
    [service_level] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [head_clinician_id] NVARCHAR(255) NULL,
    [capacity_beds] NVARCHAR(255) NULL,
    [region] NVARCHAR(255) NULL
  );
END;
GO

-- Azure SQL seed destination: bed_master
IF OBJECT_ID('dbo.bed_master', 'U') IS NULL
BEGIN
  CREATE TABLE dbo.bed_master (
    [bed_id] NVARCHAR(255) NULL,
    [department_id] NVARCHAR(255) NULL,
    [ward] NVARCHAR(255) NULL,
    [bed_type] NVARCHAR(255) NULL,
    [isolation_capable] NVARCHAR(255) NULL,
    [bed_status] NVARCHAR(255) NULL,
    [floor] NVARCHAR(255) NULL,
    [hospital_site] NVARCHAR(255) NULL,
    [active_flag] NVARCHAR(255) NULL,
    [effective_date] NVARCHAR(255) NULL
  );
END;
GO
