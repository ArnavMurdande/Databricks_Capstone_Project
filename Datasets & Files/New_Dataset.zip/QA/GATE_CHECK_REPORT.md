# Databricks 10 Capstone Dataset Rebuild — Gate Check

## Scope
- Source: original ten `NN_*Datasets.zip` archives.
- Output: ten corrected project ZIPs, combined in one archive.
- CSV filenames and column names/order: retained.
- Transaction/event CSV row counts: retained.
- Master/lookup CSV row counts: may change if necessary to cover observed lookup codes.
- Reconciliation: source keys and composite business relationships repaired with deterministic mappings.

## Executed checks
- Physical CSV files: **165**
- Logical datasets: **60**
- Direct and composite relationship checks: **105**
- Failed relationship checks: **0**
- Duplicate master/lookup primary-key checks: **0 flagged**
- Date-format screening: **1 logical datasets flagged** (see separate CSV).

## Limitations — must read before trainee release
- This rebuild intentionally focuses on **matching values across files**. It does not fully rebuild realistic business descriptions, time series, amounts, state transitions or reference effective periods.
- Source-generated placeholders may remain in descriptive columns.
- Source invalid timestamp strings may remain; see `remaining_date_format_flags.csv`.
- Synthetic mappings make keys internally consistent but do not establish real-world entity identity.
- A passing foreign-key check does not certify Gold KPI correctness, chronology, CDC semantics or business realism.
- Azure SQL, Databricks and trainee notebooks have not been executed in this QA.

## Release decision
**CONDITIONAL FOR JOIN-RELATIONSHIP TESTING ONLY; NOT APPROVED AS A FULL BUSINESS-REALISTIC CAPSTONE DATASET.**

## Next gates required for full approval
1. Business-specific semantic validation, including realistic reference attributes.
2. Strict parsing of dates/timestamps and chronological event checks.
3. Numeric constraints, currencies, code domains, and effective-dated references.
4. Gold fact/dimension grain and KPI reconciliation in Databricks.
5. End-to-end ingestion and replay testing on the target workspace.
